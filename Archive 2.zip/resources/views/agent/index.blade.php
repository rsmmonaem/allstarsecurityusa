<!DOCTYPE html>
<html>
<head>
    <title>Agent Dashboard</title>
</head>
<body>
    <h1>Welcome Agent</h1>
    <p>This is the Agent dashboard.</p>
</body>
</html>

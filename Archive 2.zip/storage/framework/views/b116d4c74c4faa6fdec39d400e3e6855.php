<?php $__env->startSection('title', 'Create Additional Info'); ?>

<?php $__env->startSection('content'); ?>
<main class="content">
    <div class="container-fluid p-0">
        <h3>Create Additional Info</h3>
        <form action="<?php echo e(route('page-additional-info.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="page_id">Page</label>
                <select name="page_id" id="page_id" class="form-control">
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($page->id); ?>"><?php echo e($page->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="key">Key</label>
                <select name="key" id="key" class="form-control" required>
                    <option value="text">Text</option>
                    <option value="image">Image</option>
                </select>
            </div>
            <div class="form-group">
                <label for="value">Value</label>
                <textarea name="value" id="value" class="form-control" placeholder="Enter text or leave this empty for image upload." required></textarea>
                <small class="form-text text-muted">If you select 'Image' for the key, use the upload field below.</small>
            </div>
            <div class="form-group" id="image-field" style="display: none;">
                <label for="image">Image (Optional)</label>
                <input type="file" name="image" id="image" class="form-control-file">
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    </div>
</main>

<script>
    document.getElementById('key').addEventListener('change', function() {
        var imageField = document.getElementById('image-field');
        if (this.value === 'image') {
            imageField.style.display = 'block';
        } else {
            imageField.style.display = 'none';
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rsmmonaem/Desktop/allstarsecurityusa/resources/views/super-admin/page-additional-info/create.blade.php ENDPATH**/ ?>
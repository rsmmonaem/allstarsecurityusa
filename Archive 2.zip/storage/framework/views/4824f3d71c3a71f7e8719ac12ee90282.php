<?php $__env->startSection('title', 'Edit Page Category'); ?>
<?php $__env->startSection('content'); ?>
<main class="content">
    <div class="container-fluid p-0">
        <h2 class="mb-4">Edit Page Category</h2>

        <form action="<?php echo e(route('page-categories.update', $pageCategory)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $pageCategory->name)); ?>" required>
            </div>
            <div class="mb-3">
                <label for="slug" class="form-label">Slug</label>
                <input type="text" class="form-control" id="slug" name="slug" value="<?php echo e(old('slug', $pageCategory->slug)); ?>" required>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Image</label>
                <input type="file" class="form-control" id="image" name="image">
                <?php if($pageCategory->image): ?>
                    <img src="<?php echo e(asset('storage/' . $pageCategory->image)); ?>" alt="Current Image" class="mt-2" style="max-width: 150px;">
                <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rsmmonaem/Desktop/allstarsecurityusa/resources/views/super-admin/page-categories/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Edit Additional Info'); ?>

<?php $__env->startSection('content'); ?>
<main class="content">
    <div class="container-fluid p-0">
        <h3>Edit Additional Info</h3>
        <form action="<?php echo e(route('page-additional-info.update', $pageAdditionalInfo)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="page_id">Page</label>
                <select name="page_id" id="page_id" class="form-control">
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($page->id); ?>" <?php echo e($page->id == $pageAdditionalInfo->page_id ? 'selected' : ''); ?>>
                            <?php echo e($page->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="key">Key</label>
                <select name="key" id="key" class="form-control" required>
                    <option value="text" <?php echo e($pageAdditionalInfo->key === 'text' ? 'selected' : ''); ?>>Text</option>
                    <option value="image" <?php echo e($pageAdditionalInfo->key === 'image' ? 'selected' : ''); ?>>Image</option>
                </select>
            </div>
            <div class="form-group">
                <label for="value">Value</label>
                
                <textarea name="value" id="summernote" class="form-control" required><?php echo e($pageAdditionalInfo->value); ?></textarea>
                <small class="form-text text-muted">If you select 'Image' for the key, use the upload field below.</small>
            </div>
            <?php if($pageAdditionalInfo->key === 'image'): ?>
                <div class="form-group">
                    <label for="current_image">Current Image</label>
                    <br>
                    <img src="<?php echo e(asset('storage/' . $pageAdditionalInfo->value)); ?>" alt="Current Image" width="100">
                </div>
            <?php endif; ?>
            <div class="form-group" id="image-field" style="<?php echo e($pageAdditionalInfo->key === 'image' ? 'display: block;' : 'display: none;'); ?>">
                <label for="image">Image (Optional)</label>
                <input type="file" name="image" id="image" class="form-control-file">
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</main>

<script>
    document.getElementById('key').addEventListener('change', function() {
        var imageField = document.getElementById('image-field');
        if (this.value === 'image') {
            imageField.style.display = 'block';
        } else {
            imageField.style.display = 'none';
        }
    });
</script>
<script>
  $('#summernote').summernote({
    tabsize: 2,
    height: 300,
    toolbar: [
      ['style', ['style']],
      ['font', ['bold', 'underline', 'clear']],
      ['color', ['color']],
      ['para', ['ul', 'ol', 'paragraph']],
      ['table', ['table']],
      ['insert', ['link', 'picture', 'video']],
      ['view', ['fullscreen', 'codeview', 'help']]
    ]
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rsmmonaem/Desktop/allstarsecurityusa/resources/views/super-admin/page-additional-info/edit.blade.php ENDPATH**/ ?>
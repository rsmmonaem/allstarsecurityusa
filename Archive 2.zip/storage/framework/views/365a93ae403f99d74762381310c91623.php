<?php $__env->startSection('title', 'Edit Contact Us'); ?>
<?php $__env->startSection('description', 'Edit Contact Us Content'); ?>
<?php $__env->startSection('keywords', 'Edit,Contact us'); ?>

<?php $__env->startSection('content'); ?>
    <!-- =======================Edit Contact Us START -->
    <form method="POST" action="<?php echo e(route('admin.update_contact_us')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <textarea id="editor" name="contact_us_content"><?php echo e($data); ?></textarea>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>

    <script src="https://cdn.tiny.cloud/1/5ul74oiu8td5u6fc926suxj9ribdsoime97mptwb7959aszm/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
        tinymce.init({
            selector: '#editor',
            plugins: 'link paste table',
            toolbar: 'undo redo | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
            menubar: false,
            height: 500,
            content_css: [
            '<?php echo e(asset('frontend/assets/css/style.css')); ?>', // Link your main stylesheet
            '<?php echo e(asset('frontend/assets/vendor/font-awesome/css/all.min.css')); ?>',
            '<?php echo e(asset('frontend/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>'
        ],
        });
    </script>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    <!-- =======================
    Edit Contact Us END -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rsmmonaem/Desktop/allstarsecurityusa/resources/views/frontend/pages/edit_contact_us.blade.php ENDPATH**/ ?>
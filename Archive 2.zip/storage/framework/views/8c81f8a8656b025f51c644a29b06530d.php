<?php $__env->startSection('title', 'Create Page Category'); ?>
<?php $__env->startSection('content'); ?>
<main class="content">
    <div class="container-fluid p-0">
        <h2 class="mb-4">Create Page Category</h2>

        <form action="<?php echo e(route('page-categories.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="slug" class="form-label">Slug</label>
                <input type="text" class="form-control" id="slug" name="slug" required>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Image</label>
                <input type="file" class="form-control" id="image" name="image">
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rsmmonaem/Desktop/allstarsecurityusa/resources/views/super-admin/page-categories/create.blade.php ENDPATH**/ ?>
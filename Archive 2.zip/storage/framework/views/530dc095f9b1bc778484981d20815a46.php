<!DOCTYPE html>
<html lang="en">
<head>
   <?php echo $__env->make('frontend.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
   <body>
      <?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <main>
         <?php echo $__env->yieldContent('content'); ?>
      </main>
      <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="back-top"></div>
      <!-- Bootstrap JS -->
      <script src="<?php echo e(asset('frontend/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
      <!-- Theme Functions -->
      <script src="<?php echo e(asset('frontend/assets/js/functions.js')); ?>"></script>
      


     

   </body>
</html>
<?php /**PATH /Users/rsmmonaem/Desktop/allstarsecurityusa/resources/views/layout/frontend.blade.php ENDPATH**/ ?>
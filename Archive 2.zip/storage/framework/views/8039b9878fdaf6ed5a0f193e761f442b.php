<?php $__env->startSection('title', 'Additional Info List'); ?>

<?php $__env->startSection('content'); ?>
<main class="content">
    <div class="container-fluid p-0">
        <h3>Additional Info List</h3>
        <a href="<?php echo e(route('page-additional-info.create')); ?>" class="btn btn-primary mb-3">Add New</a>
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Current Additional Info</h5>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Page</th>
                            <th>Key</th>
                            <th>Value</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $additionalInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($info->id); ?></td>
                                <td><?php echo e($info->page->name); ?></td>
                                <td><?php echo e(ucfirst($info->key)); ?></td>
                                <td>
                                    <?php if($info->key === 'image' && strpos($info->value, 'images/page_additional_info') !== false): ?>
                                        <img src="<?php echo e(asset('storage/' . $info->value)); ?>" alt="Image" width="100">
                                    <?php else: ?>
                                        <?php echo e($info->value); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('page-additional-info.edit', $info)); ?>" class="btn btn-warning">Edit</a>
                                    <form action="<?php echo e(route('page-additional-info.destroy', $info)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rsmmonaem/Desktop/allstarsecurityusa/resources/views/super-admin/page-additional-info/index.blade.php ENDPATH**/ ?>
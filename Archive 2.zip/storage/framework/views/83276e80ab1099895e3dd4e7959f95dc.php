<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-12 text-center">
                <p class="mb-0">
                    <a href="https://allstarsecurityusa.com/" target="_blank" class="text-muted"><strong>Allstarsecurityusa</strong></a> &copy;
                </p>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /Users/rsmmonaem/Desktop/allstarsecurityusa/resources/views/includes/footer.blade.php ENDPATH**/ ?>